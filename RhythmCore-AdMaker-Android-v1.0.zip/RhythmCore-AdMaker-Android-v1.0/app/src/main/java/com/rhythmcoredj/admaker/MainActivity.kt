package com.rhythmcoredj.admaker

import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.media3.common.C
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Contrast
import androidx.media3.effect.Presentation
import androidx.media3.effect.RgbAdjustment
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import com.google.common.collect.ImmutableList
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.random.Random

@OptIn(UnstableApi::class)
class MainActivity : ComponentActivity() {
    private val selectedMedia = mutableListOf<Uri>()
    private var musicUri: Uri? = null
    private var lastOutput: File? = null
    private var transformer: Transformer? = null

    private lateinit var mediaText: TextView
    private lateinit var musicText: TextView
    private lateinit var statusText: TextView
    private lateinit var durationSpinner: Spinner
    private lateinit var renderButton: Button
    private lateinit var saveButton: Button
    private lateinit var shareButton: Button
    private lateinit var randomizeButton: Button
    private lateinit var progressBar: ProgressBar

    private val pickMedia = registerForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(40)
    ) { uris ->
        if (uris.isNotEmpty()) {
            selectedMedia.clear()
            selectedMedia.addAll(uris.take(40))
            mediaText.text = "${selectedMedia.size} media item${if (selectedMedia.size == 1) "" else "s"} selected"
            statusText.text = "Ready to build your commercial."
        }
    }

    private val pickMusic = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        musicUri = uri
        musicText.text = if (uri == null) "No music selected" else "Music selected"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(24), dp(22), dp(24))
            setBackgroundColor(Color.WHITE)
        }

        val title = TextView(this).apply {
            text = "RhythmCoreDJ\nAdMaker"
            textSize = 34f
            setTextColor(Color.BLACK)
            typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))

        root.addView(TextView(this).apply {
            text = "AUTOMATED COMMERCIAL GENERATOR • ANDROID"
            textSize = 12f
            gravity = Gravity.CENTER_HORIZONTAL
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(4), 0, dp(22))
        })

        val addMedia = bigButton("ADD PHOTOS + VIDEOS") {
            pickMedia.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
        }
        root.addView(addMedia)

        mediaText = infoText("No media selected • up to 40")
        root.addView(mediaText)

        root.addView(bigButton("ADD MUSIC") { pickMusic.launch("audio/*") })
        musicText = infoText("No music selected")
        root.addView(musicText)

        val label = infoText("Commercial length")
        label.setPadding(0, dp(16), 0, dp(4))
        root.addView(label)

        durationSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                listOf("10 seconds", "15 seconds", "20 seconds", "30 seconds")
            )
            setSelection(1)
        }
        root.addView(durationSpinner, LinearLayout.LayoutParams(-1, dp(52)))

        renderButton = bigButton("GENERATE COMMERCIAL") { renderCommercial() }
        root.addView(renderButton)

        randomizeButton = bigButton("RANDOMIZE AGAIN") { renderCommercial() }.apply { isEnabled = false }
        root.addView(randomizeButton)

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
            setPadding(0, dp(14), 0, 0)
        }
        root.addView(progressBar, LinearLayout.LayoutParams(-1, dp(32)))

        statusText = infoText("Add media to begin.").apply {
            gravity = Gravity.CENTER_HORIZONTAL
            textSize = 15f
            setPadding(0, dp(12), 0, dp(16))
        }
        root.addView(statusText)

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        saveButton = smallButton("SAVE") { saveToGallery() }.apply { isEnabled = false }
        shareButton = smallButton("SHARE") { shareVideo() }.apply { isEnabled = false }
        actions.addView(saveButton, LinearLayout.LayoutParams(0, dp(54), 1f).apply { marginEnd = dp(6) })
        actions.addView(shareButton, LinearLayout.LayoutParams(0, dp(54), 1f).apply { marginStart = dp(6) })
        root.addView(actions)

        val footer = infoText("9:16 • 1080 × 1920 • vintage/static intro + outro • randomized treatment")
        footer.gravity = Gravity.CENTER_HORIZONTAL
        footer.setPadding(0, dp(18), 0, 0)
        root.addView(footer)

        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
    }

    private fun bigButton(text: String, onClick: () -> Unit): Button = Button(this).apply {
        this.text = text
        textSize = 16f
        isAllCaps = false
        typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        setOnClickListener { onClick() }
        setPadding(dp(8), dp(8), dp(8), dp(8))
    }

    private fun smallButton(text: String, onClick: () -> Unit): Button = bigButton(text, onClick)

    private fun infoText(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 14f
        setTextColor(Color.DKGRAY)
        typeface = Typeface.create(Typeface.SERIF, Typeface.NORMAL)
        setPadding(0, dp(5), 0, dp(10))
    }

    private fun durationMs(): Long = when (durationSpinner.selectedItemPosition) {
        0 -> 10_000L
        2 -> 20_000L
        3 -> 30_000L
        else -> 15_000L
    }

    private fun renderCommercial() {
        if (selectedMedia.isEmpty()) {
            Toast.makeText(this, "Add photos or videos first.", Toast.LENGTH_SHORT).show()
            return
        }
        transformer?.cancel()
        renderButton.isEnabled = false
        randomizeButton.isEnabled = false
        saveButton.isEnabled = false
        shareButton.isEnabled = false
        progressBar.visibility = View.VISIBLE
        progressBar.isIndeterminate = true
        statusText.text = "Building vintage RhythmCoreDJ commercial…"

        try {
            val totalMs = durationMs()
            val introMs = if (totalMs <= 10_000L) 900L else 1_250L
            val outroMs = introMs
            val contentMs = max(1_500L, totalMs - introMs - outroMs)
            val slotMs = max(180L, contentMs / selectedMedia.size)

            val items = mutableListOf<EditedMediaItem>()
            items += buildStaticTitleSequence("RHYTHMCORE\nDJ", introMs, true)
            selectedMedia.forEachIndexed { index, uri ->
                items += makeMediaItem(uri, slotMs, index)
            }
            items += buildStaticTitleSequence("RHYTHMCORE\nDJ", outroMs, false)

            val sequences = mutableListOf<EditedMediaItemSequence>()
            sequences += EditedMediaItemSequence.Builder(setOf(C.TRACK_TYPE_VIDEO))
                .addItems(items)
                .build()

            musicUri?.let { music ->
                val clippedMusic = MediaItem.Builder()
                    .setUri(music)
                    .setClippingConfiguration(
                        MediaItem.ClippingConfiguration.Builder()
                            .setStartPositionMs(0)
                            .setEndPositionMs(totalMs)
                            .build()
                    )
                    .build()
                val audio = EditedMediaItem.Builder(clippedMusic).setRemoveVideo(true).build()
                sequences += EditedMediaItemSequence.Builder(setOf(C.TRACK_TYPE_AUDIO))
                    .addItem(audio)
                    .setIsLooping(true)
                    .build()
            }

            val composition = Composition.Builder(sequences).build()

            val outDir = File(cacheDir, "exports").apply { mkdirs() }
            val output = File(outDir, "RhythmCore-AdMaker-${System.currentTimeMillis()}.mp4")
            if (output.exists()) output.delete()

            transformer = Transformer.Builder(this)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        runOnUiThread {
                            lastOutput = output
                            progressBar.visibility = View.GONE
                            statusText.text = "Commercial finished — ready to save or share."
                            renderButton.isEnabled = true
                            randomizeButton.isEnabled = true
                            saveButton.isEnabled = true
                            shareButton.isEnabled = true
                        }
                    }

                    override fun onError(
                        composition: Composition,
                        exportResult: ExportResult,
                        exportException: ExportException
                    ) {
                        runOnUiThread {
                            progressBar.visibility = View.GONE
                            statusText.text = "Render failed: ${exportException.localizedMessage ?: "Unknown encoder error"}"
                            renderButton.isEnabled = true
                            randomizeButton.isEnabled = true
                        }
                    }
                })
                .build()

            transformer!!.start(composition, output.absolutePath)
        } catch (t: Throwable) {
            progressBar.visibility = View.GONE
            statusText.text = "Could not start render: ${t.localizedMessage}"
            renderButton.isEnabled = true
            randomizeButton.isEnabled = true
        }
    }

    private fun makeMediaItem(uri: Uri, slotMs: Long, index: Int): EditedMediaItem {
        val mime = contentResolver.getType(uri).orEmpty()
        val isVideo = mime.startsWith("video/")
        val media = if (isVideo) {
            MediaItem.Builder()
                .setUri(uri)
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(0)
                        .setEndPositionMs(slotMs)
                        .build()
                )
                .build()
        } else {
            MediaItem.Builder().setUri(uri).setImageDurationMs(slotMs).build()
        }

        val visualEffects = mutableListOf<Effect>()
        visualEffects += Presentation.createForWidthAndHeight(1080, 1920, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP)

        when ((index + Random.nextInt(5)) % 5) {
            0 -> visualEffects += Contrast(0.12f)
            1 -> visualEffects += RgbAdjustment.Builder().setRedScale(1.02f).setGreenScale(0.98f).setBlueScale(0.94f).build()
            2 -> visualEffects += ScaleAndRotateTransformation.Builder().setScale(1.015f, 1.015f).build()
            3 -> visualEffects += Contrast(0.20f)
            else -> visualEffects += RgbAdjustment.Builder().setRedScale(0.97f).setGreenScale(0.99f).setBlueScale(1.02f).build()
        }

        return EditedMediaItem.Builder(media)
            .setFrameRate(30)
            .setRemoveAudio(true)
            .setEffects(Effects(ImmutableList.of(), ImmutableList.copyOf(visualEffects)))
            .build()
    }

    private fun buildStaticTitleSequence(text: String, totalMs: Long, intro: Boolean): List<EditedMediaItem> {
        val count = 8
        val perFrame = max(70L, totalMs / count)
        return (0 until count).map { i ->
            val bmp = makeTitleBitmap(text, i, intro)
            val file = File(cacheDir, "rc_title_${if (intro) "in" else "out"}_${System.nanoTime()}_$i.png")
            FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            bmp.recycle()
            val media = MediaItem.Builder().setUri(Uri.fromFile(file)).setImageDurationMs(perFrame).build()
            EditedMediaItem.Builder(media)
                .setFrameRate(30)
                .setRemoveAudio(true)
                .setEffects(
                    Effects(
                        ImmutableList.of(),
                        ImmutableList.of(
                            Presentation.createForWidthAndHeight(1080, 1920, Presentation.LAYOUT_SCALE_TO_FIT)
                        )
                    )
                )
                .build()
        }
    }

    private fun makeTitleBitmap(text: String, frame: Int, intro: Boolean): Bitmap {
        val w = 1080
        val h = 1920
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bitmap)
        c.drawColor(Color.rgb(8, 8, 8))
        val noisePaint = Paint().apply { strokeWidth = 2f }
        repeat(360) {
            val gray = Random.nextInt(20, 145)
            noisePaint.color = Color.rgb(gray, gray, gray)
            val y = Random.nextInt(h).toFloat()
            c.drawLine(0f, y, w.toFloat(), y, noisePaint)
        }
        val blockPaint = Paint()
        repeat(10) {
            val alpha = Random.nextInt(25, 100)
            blockPaint.color = Color.argb(alpha, 255, 255, 255)
            val y = Random.nextInt(h)
            c.drawRect(0f, y.toFloat(), w.toFloat(), (y + Random.nextInt(2, 18)).toFloat(), blockPaint)
        }
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (frame % 3 == 0) Color.rgb(180, 50, 210) else Color.WHITE
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            textSize = 152f
            letterSpacing = 0.08f
        }
        val lines = text.split("\n")
        val jitterX = Random.nextInt(-20, 21).toFloat()
        val jitterY = Random.nextInt(-14, 15).toFloat()
        val centerY = h / 2f + jitterY
        lines.forEachIndexed { index, line ->
            c.drawText(line, w / 2f + jitterX, centerY + (index - 0.5f) * 180f, p)
        }
        val sub = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.LTGRAY
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            textSize = 42f
        }
        c.drawText(if (intro) "AUTOMATED COMMERCIAL" else "RHYTHMCOREDJ.COM", w / 2f, centerY + 230f, sub)
        return bitmap
    }

    private fun saveToGallery() {
        val source = lastOutput ?: return
        try {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, "RhythmCore-AdMaker-${System.currentTimeMillis()}.mp4")
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/RhythmCoreDJ")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: error("Could not create MediaStore item")
            contentResolver.openOutputStream(uri)?.use { out -> source.inputStream().use { it.copyTo(out) } }
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)
            statusText.text = "Saved to Movies/RhythmCoreDJ."
        } catch (t: Throwable) {
            statusText.text = "Save failed: ${t.localizedMessage}"
        }
    }

    private fun shareVideo() {
        val source = lastOutput ?: return
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", source)
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }, "Share RhythmCore commercial"))
    }

    override fun onDestroy() {
        transformer?.cancel()
        super.onDestroy()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
