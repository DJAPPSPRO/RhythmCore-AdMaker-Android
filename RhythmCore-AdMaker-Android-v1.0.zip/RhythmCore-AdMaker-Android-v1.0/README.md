# RhythmCore AdMaker Android v1.0

Native Android proof-of-concept for the RhythmCoreDJ automated commercial generator.

## Included in v1.0
- Select up to 40 mixed photos/videos with Android Photo Picker.
- Optional music track.
- 10 / 15 / 20 / 30 second commercial lengths.
- Automatic per-item timing.
- 9:16 1080x1920 output target.
- Procedural vintage/static RhythmCoreDJ intro and outro.
- Randomized contrast/color/micro-scale treatment each render.
- H.264 video + AAC audio export with AndroidX Media3 Transformer.
- Save to `Movies/RhythmCoreDJ` and Android share sheet.
- Separate Android package: `com.rhythmcoredj.admaker`.

## Open/build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Run on an Android 6.0+ device (Android 13+ recommended for the modern system picker experience).
4. Tap **ADD PHOTOS + VIDEOS**, choose up to 40 items, optionally add music, then **GENERATE COMMERCIAL**.

## Notes
- This build intentionally does not touch the Mac AdMaker project.
- The intro/outro static is generated locally on-device.
- `RANDOMIZE AGAIN` makes a new visual treatment from the same selected media.
- Some unusually encoded source videos may need transcoding support beyond a device's built-in codec set.

## Optional one-click cloud APK build
A GitHub Actions workflow is included at `.github/workflows/build-android.yml`. Push the project to GitHub and run **Build Android APK** from the Actions tab; the debug APK is uploaded as a workflow artifact.
